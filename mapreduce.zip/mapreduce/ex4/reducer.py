#!/usr/bin/env python

from operator import itemgetter
import sys

current_key = None
min_value = 0
max_value = 0
sum = 0
count = 0

# input comes from STDIN
for line in sys.stdin:
	# remove leading and trailing whitespace
	line = line.strip()
	row = line.split("\t")
	(key,value) = row

	try: 
		value = int(value)
	except ValueError:
		continue

	# this IF-switch only works because Hadoop sorts map output
	# by key (here: word) before it is passed to the reducer
	if current_key == (key):
    		min_value = min(min_value, value)
            max_value = max(max_value, value)
            sum += value
		    count += 1
	else:
		if current_key:
	 		# write result to STDOUT
			print('({},{},{},{})\t{}'.format(current_key,min_value,max_value,float(sum)/count,count))
		current_key = key
        min_value = value
        max_value = value
		sum = value
		count = 1


if current_key == key:
	print('({},{},{},{})\t{}'.format(current_key,min_value,max_value,float(sum)/count,count))